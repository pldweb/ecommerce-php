<?php


define('BASE_URL', 'http://ecommerce.it');
define('SCRIPT_PATH', BASE_URL . '/app/assets');

// DB
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '12345');
define('DB_NAME', 'ecommerce');
