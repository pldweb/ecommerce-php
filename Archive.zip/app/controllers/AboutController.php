<?php


class About {

    public function index($nama = '') {
        echo "Nama saya adalah $nama";
    }

}