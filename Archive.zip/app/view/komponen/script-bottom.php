</div>
<script src="<?= SCRIPT_PATH ?>/js/bootstrap.bundle.js"></script>
</body>
</html>